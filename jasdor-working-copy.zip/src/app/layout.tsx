import type { Metadata, Viewport } from 'next';
import './globals.css';

export const metadata: Metadata = {
  metadataBase: new URL('https://jasdor.cimagroup.my.id'),
  title: {
    default: 'Jasdor — Jastip Kopi Kenangan Promo Setengah Harga',
    template: '%s | Jasdor — Jastip Kopi Kenangan',
  },
  description:
    'Jastip Kopi Kenangan hemat promo setengah harga (diskon 50%). Pesan mudah langsung dari HP, biaya jasa mulai Rp2.000/item, checkout otomatis via WhatsApp.',
  applicationName: 'Jasdor',
  appleWebApp: {
    capable: true,
    statusBarStyle: 'default',
    title: 'Jasdor',
  },
  manifest: '/manifest.webmanifest',
  icons: {
    icon: [
      { url: '/icons/icon-192x192.png', sizes: '192x192', type: 'image/png' },
      { url: '/icons/icon-512x512.png', sizes: '512x512', type: 'image/png' },
    ],
    shortcut: '/icons/icon-192x192.png',
    apple: '/icons/apple-touch-icon.png',
  },
  openGraph: {
    title: 'Jasdor — Jastip Kopi Kenangan Promo Setengah Harga',
    description:
      'Jastip Kopi Kenangan hemat promo setengah harga (diskon 50%). Pesan mudah langsung dari HP, biaya jasa mulai Rp2.000/item, checkout otomatis via WhatsApp.',
    url: 'https://jasdor.cimagroup.my.id',
    siteName: 'Jasdor',
    images: [
      {
        url: '/og-image.png',
        width: 1200,
        height: 630,
        alt: 'Jasdor — Jastip Kopi Kenangan Promo Setengah Harga',
      },
    ],
    locale: 'id_ID',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Jasdor — Jastip Kopi Kenangan Promo Setengah Harga',
    description:
      'Jastip Kopi Kenangan hemat promo setengah harga (diskon 50%). Pesan mudah langsung dari HP, biaya jasa mulai Rp2.000/item, checkout otomatis via WhatsApp.',
    images: ['/og-image.png'],
  },
};

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  themeColor: '#111111',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const cfAnalyticsToken = process.env.NEXT_PUBLIC_CF_ANALYTICS_TOKEN;

  return (
    <html lang="id">
      <head>
        <link rel="manifest" href="/manifest.webmanifest" />
        <link rel="apple-touch-icon" href="/icons/apple-touch-icon.png" />
        <meta name="theme-color" content="#111111" />
      </head>
      <body className="bg-stone-100 text-stone-800 antialiased selection:bg-amber-400 selection:text-black">
        <div className="min-h-screen max-w-md mx-auto bg-white shadow-2xl flex flex-col relative overflow-x-clip">
          <div className="flex-1 flex flex-col">
            {children}
          </div>
          <footer className="mt-auto py-4 px-4 text-center border-t border-stone-200/70 bg-stone-50">
            <p className="text-[11px] text-stone-600 font-medium leading-relaxed">
              Layanan jasa titip independen, bukan afiliasi resmi Kopi Kenangan.
            </p>
          </footer>
        </div>

        {/* Minimal PWA Service Worker Registration (Installability Only) */}
        <script
          dangerouslySetInnerHTML={{
            __html: `if('serviceWorker' in navigator){window.addEventListener('load',function(){navigator.serviceWorker.register('/sw.js').catch(function(){});});}`,
          }}
        />

        {/* Cloudflare Web Analytics (HANYA bila token terisi di env) */}
        {cfAnalyticsToken ? (
          <script
            defer
            src="https://static.cloudflareinsights.com/beacon.min.js"
            data-cf-beacon={JSON.stringify({ token: cfAnalyticsToken })}
          />
        ) : null}
      </body>
    </html>
  );
}
